package com.example.Components;

import com.example.Models.User;

public class Account {
    private String user_type;
    private User user_data;

    public Account(){
        user_type = "Denied";
    }

    public Account(User u_data) {
        user_data = u_data;
        user_type = u_data.getRlUser().toString();
    }

    public String getUserType(){
        return user_type;
    }

    public User getUserData(){
        return user_data;
    }
}
