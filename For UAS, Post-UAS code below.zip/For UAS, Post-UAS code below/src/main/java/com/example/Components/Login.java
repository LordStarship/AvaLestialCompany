package com.example.Components;

import java.util.List;

import com.example.DB;
import com.example.Models.User;
import com.example.Components.Account;

public class Login {
    private String email;
    private String pw;
    private String u_name;

    public Login(String em_u, String pw_u){
        email = em_u;
        pw = pw_u;
    }

    public String getCurrentUser(){
        return u_name;
    }

    public Account authenticate(){
        DB db = new DB();

        String query = "SELECT * FROM pengguna WHERE email_user = '" + email + "' and password_user = '" + pw + "'";
        System.out.println(query);

        List<Object> rs = db.runQuery(query);
        if(!rs.isEmpty()){
            return new Account(new User(rs.get(0)));
        }
        else{
            return new Account();
        }
    }
}
