package com.example.Models;
import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Barang {
    private final StringProperty idBarang = new SimpleStringProperty();
    private final StringProperty idGame = new SimpleStringProperty();
    private final StringProperty nmBarang = new SimpleStringProperty();
    private final StringProperty emBarang = new SimpleStringProperty();
    private final StringProperty amBarang = new SimpleStringProperty();

    public Barang(Object obj){
        List<String> list = ((ArrayList<String>) obj);

        idBarang.set(list.get(0).toString());
        idGame.set(list.get(1).toString());
        nmBarang.set(list.get(2).toString());
        emBarang.set(list.get(3).toString());
        amBarang.set(list.get(4).toString());
    }

    public StringProperty idBarangProperty() {
        return idBarang;
    }

    public String getIdBarang() {
        return idBarang.get();
    }

    public void setIdBarang(String idBarang) {
        this.idBarang.set(idBarang);
    }

    public StringProperty idGameProperty() {
        return idGame;
    }

    public String getIdGame() {
        return idGame.get();
    }

    public void setIdGame(String idGame) {
        this.idGame.set(idGame);
    }

    public StringProperty nmBarangProperty() {
        return nmBarang;
    }

    public String getNmBarang() {
        return nmBarang.get();
    }

    public void setNmBarang(String nmBarang) {
        this.nmBarang.set(nmBarang);
    }

    public StringProperty emBarangProperty() {
        return emBarang;
    }

    public String getEmBarang() {
        return emBarang.get();
    }

    public void setEmBarang(String emBarang) {
        this.emBarang.set(emBarang);
    }

    public StringProperty amBarangProperty() {
        return amBarang;
    }

    public String getAmBarang() {
        return amBarang.get();
    }

    public void setAmBarang(String amBarang) {
        this.amBarang.set(amBarang);
    }
}
