package com.example.Models;
import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class User {
    private final StringProperty idUser = new SimpleStringProperty();
    private final StringProperty nmUser = new SimpleStringProperty();
    private final StringProperty rlUser = new SimpleStringProperty();
    private final StringProperty pwUser = new SimpleStringProperty();
    private final StringProperty unUser = new SimpleStringProperty();
    private final StringProperty emUser = new SimpleStringProperty();

    public User(Object obj){
        List<String> list = ((ArrayList<String>) obj);

        idUser.set(list.get(0).toString());
        nmUser.set(list.get(1).toString());
        rlUser.set(list.get(2).toString());
        pwUser.set(list.get(3).toString());
        unUser.set(list.get(4).toString());
        emUser.set(list.get(5).toString());
    }

    public StringProperty idUserProperty() {
        return idUser;
    }

    public String getIdUser() {
        return idUser.get();
    }

    public void setIdUser(String idUser) {
        this.idUser.set(idUser);
    }

    public StringProperty nmUserProperty() {
        return nmUser;
    }

    public String getNmUser() {
        return nmUser.get();
    }

    public void setNmUser(String nmUser) {
        this.nmUser.set(nmUser);
    }

    public StringProperty rlUserProperty() {
        return rlUser;
    }

    public String getRlUser() {
        return rlUser.get();
    }

    public void setRlUser(String rlUser) {
        this.rlUser.set(rlUser);
    }

    public StringProperty pwUserProperty() {
        return pwUser;
    }

    public String getPwUser() {
        return pwUser.get();
    }

    public void setPwUser(String pwUser) {
        this.pwUser.set(pwUser);
    }

    public StringProperty unUserProperty() {
        return unUser;
    }

    public String getUnUser() {
        return unUser.get();
    }

    public void setUnUser(String unUser) {
        this.unUser.set(unUser);
    }

    public StringProperty emUserProperty() {
        return emUser;
    }

    public String getEmUser() {
        return emUser.get();
    }

    public void setEmUser(String emUser) {
        this.emUser.set(emUser);
    }
}
