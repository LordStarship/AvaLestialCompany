package com.example.Layout.Table;

import java.util.ArrayList;
import java.util.List;

import com.example.DB;
import com.example.Models.Barang;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

public class TableBarang implements Table{
    private final BorderPane rootPane;
    
    private List<Barang> listBarang;
    private TableView<Barang> tb = new TableView<Barang>();

    public TableBarang(){
        rootPane = new BorderPane();
        tb.setColumnResizePolicy((param) -> true);

        rootPane.setTop(filterPane());
        rootPane.setCenter(getTable());
    }

    public HBox filterPane(){
        HBox filterPane = new HBox();
        List<Node> paneList = new ArrayList<Node>();
        
        Label namaTabel = new Label("Data Barang");
        TextField searchBar = new TextField();
        // ComboBox<String> jenis = new ComboBox<String>();
        
        // jenis.getItems().addAll(
        //     "Contoh1",
        //     "Contoh2",
        //     "Contoh3"
        // );

        paneList.add(namaTabel);
        paneList.add(searchBar);
        // paneList.add(jenis);

        filterPane.setSpacing(20);
        filterPane.setAlignment(Pos.CENTER);
        filterPane.setPadding(new Insets(0, 0, 20, 0));
        namaTabel.getStyleClass().addAll(new String[]{"table-title"});

        for(int x = 0; x < paneList.size(); x++){
            Region r = new Region();
            HBox.setHgrow(r, Priority.ALWAYS);

            if(x != paneList.size() - 1){
                filterPane.getChildren().addAll(paneList.get(x), r);
            }
            else{
                filterPane.getChildren().addAll(paneList.get(x));
            }
        }

        return filterPane;
    }

    public TableView<Barang> createTable(){
        TableColumn<Barang, String> col_idb = new TableColumn<>("ID Barang");
        TableColumn<Barang, String> col_idg = new TableColumn<>("ID Game");
        TableColumn<Barang, String> col_nm = new TableColumn<>("Nama Barang");
        TableColumn<Barang, String> col_em = new TableColumn<>("Email");
        TableColumn<Barang, String> col_am = new TableColumn<>("Amount");

        col_idb.setCellValueFactory(v -> v.getValue().idBarangProperty());
        col_idg.setCellValueFactory(v -> v.getValue().idGameProperty());
        col_nm.setCellValueFactory(v -> v.getValue().nmBarangProperty());
        col_em.setCellValueFactory(v -> v.getValue().emBarangProperty());
        col_am.setCellValueFactory(v -> v.getValue().amBarangProperty());

        ArrayList<TableColumn<Barang, String>> col = new ArrayList<>();
        col.add(col_idb);
        col.add(col_idg);
        col.add(col_nm);
        col.add(col_em);
        col.add(col_am);

        for(int i = 0; i < col.size(); i++){
            col.get(i).prefWidthProperty().bind(tb.widthProperty().divide(col.size()));
            tb.getColumns().add(col.get(i));
        }

        return tb;
    }

    public HBox getTable(){
        HBox table = new HBox();
        TableView<Barang> tb = createTable();

        // table.prefWidthProperty().bind(rootPane.widthProperty());
        HBox.setHgrow(table, Priority.ALWAYS);
        HBox.setHgrow(tb, Priority.ALWAYS);
        VBox.setVgrow(tb, Priority.ALWAYS);

        List<Barang> list_Barang = getData();
        // SimpleDateFormat formatter = new SimpleDateFormat("dd MMMM yyyy, hh:mm");   

        for(int y = 0; y < list_Barang.size(); y++){
            tb.getItems().add(list_Barang.get(y));
            // System.out.println(list_mhswa.get(y).tgl_ditambah);        
        }

        table.getChildren().add(tb);

        return table;
    }

    public List<Barang> getData(){
        DB db = new DB();

        List<Object> rs = db.runQuery("SELECT * FROM barang");
        listBarang = new ArrayList<Barang>();

        for(int i = 0; i < rs.size(); i++){
            // System.out.println(rs.get(i));
            Barang Barang = new Barang(rs.get(i));

            listBarang.add(Barang);
        }
        
        return listBarang;
    }

    public BorderPane getPane(){
        return rootPane;
    }
}
